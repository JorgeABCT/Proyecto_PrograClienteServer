/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Listas_Nodos;

import javax.swing.JOptionPane;
import Clientes.Tarjeta;

/**
 *
 * @author XPC
 */
public class ListaTarjetas {

    private NodoTarjeta cabeza;

    public ListaTarjetas() {
        this.cabeza = null;
    }
    
    public void Reinicio(){
        cabeza = null;
    }

    public void agregarTarjetaBD(Tarjeta tarjeta) {
        NodoTarjeta nuevo = new NodoTarjeta(tarjeta);
        if(cabeza==null){
            cabeza = nuevo;
        }else if(tarjeta.getPropietario()<=cabeza.getTarjeta().getPropietario()){
            nuevo.setSiguiente(cabeza);
            cabeza=nuevo;
        }else if(cabeza.getSiguiente()==null){
            cabeza.setSiguiente(nuevo);
        }else{
            NodoTarjeta aux=this.cabeza;
            while(aux.getSiguiente()!=null && aux.getSiguiente().getTarjeta().getPropietario()<tarjeta.getPropietario()){
                aux=aux.getSiguiente();
            }
            nuevo.setSiguiente(aux.getSiguiente());
            aux.setSiguiente(nuevo);
        }
    }

    public String mostrarTarjetas() {
        NodoTarjeta aux = cabeza;
        String guardar = "";
        while (aux != null) {
            guardar += aux.getTarjeta().toString();
            aux = aux.getSiguiente();
        }
        return guardar;
    }

    public StringBuilder buscar(int cedula) {
        NodoTarjeta aux = cabeza;
        StringBuilder guardar = new StringBuilder();
        while (aux != null) {
            if (aux.getTarjeta().getPropietario() == cedula) { //lo busca si lo encuentra muestra los datos
                guardar.append("-----------------------------------------------");
                guardar.append("\nPropietario: ").append(aux.getTarjeta().getPropietario());
                guardar.append("\nNumero de Tarjeta: ").append(aux.getTarjeta().getNumeroTarjeta());
                guardar.append("\nCVV: ").append(aux.getTarjeta().getCVV());
                guardar.append("\nFecha de Vencimiento: ").append(aux.getTarjeta().getFechaVencimiento());
                guardar.append("\nBalance: ").append(aux.getTarjeta().getBalance());
                guardar.append("\nActiva: " + aux.getTarjeta().isActiva());
                guardar.append("\n");
            }
            aux = aux.getSiguiente();
        }
        return guardar;
    }
    
    public int cantidadT(int cedula) {
        NodoTarjeta aux = cabeza;
        int tarjetas = 0;
        while (aux != null) {
            if (aux.getTarjeta().getPropietario() == cedula && aux.getTarjeta().isActiva()) { //lo busca si lo encuentra muestra los datos
                tarjetas++;
            }
            aux = aux.getSiguiente();
        }
        return tarjetas;
    }
    
    public void cambiarSaldo(String numeros, int balance) {
        NodoTarjeta aux = cabeza;
        while (aux != null) {
            if (aux.getTarjeta().getNumeroTarjeta().equals(numeros)) { //lo busca si lo encuentra muestra los datos
                aux.getTarjeta().setBalance(balance);
            }
            aux = aux.getSiguiente();
        }
    }
    
    public String[] getTarjetas(int cedula, int cantidad){
        NodoTarjeta aux = cabeza;
        String[] opciones = new String[cantidad];
        int contador = 0;
        while (aux != null) {
            if (aux.getTarjeta().getPropietario() == cedula && aux.getTarjeta().isActiva()) { //lo busca si lo encuentra muestra los datos
                opciones[contador] = aux.getTarjeta().getNumeroTarjeta();
                contador++;
            }
            aux = aux.getSiguiente();
        }
        return opciones;
    }
    
    public Tarjeta getTarjeta(String numeros) {
        NodoTarjeta aux = cabeza;
        while (aux != null) {
            if (aux.getTarjeta().getNumeroTarjeta().equals(numeros)) { //lo busca si lo encuentra muestra los datos
                return aux.getTarjeta();
            }
            aux = aux.getSiguiente();
        }
        return null;
    }
    
    public StringBuilder getTarjetaPropietario() {
        NodoTarjeta aux = cabeza;
        StringBuilder guardar = new StringBuilder();
        while (aux != null) {
            guardar.append("-----------------------------");
            guardar.append("\nPropietario: ").append(aux.getTarjeta().getPropietario()).append("\n");
            guardar.append("Numero de Tarjeta: ").append(aux.getTarjeta().getNumeroTarjeta());
            guardar.append("\nActiva: ").append(aux.getTarjeta().isActiva());
            aux = aux.getSiguiente();
        }
        return guardar;
    }
    
    public Tarjeta getTarjeta(int cedula) {
        NodoTarjeta aux = cabeza;
        while (aux != null) {
            if (aux.getTarjeta().getPropietario() == cedula && aux.getTarjeta().isActiva()) { //lo busca si lo encuentra muestra los datos
                return aux.getTarjeta();
            }
            aux = aux.getSiguiente();
        }
        return null;
    }
    
    public String deshabilitarT(int cedula, String numeros) {
        NodoTarjeta aux = cabeza;
        while (aux != null) {
            if (aux.getTarjeta().getPropietario() == cedula && aux.getTarjeta().getNumeroTarjeta().equals(numeros)) { //lo busca si lo encuentra muestra los datos
                if(!aux.getTarjeta().isActiva()){
                    return "Tarjeta ya desactivada";
                }else{
                aux.getTarjeta().setActiva(false);
                return "Se inhabilito la tarjeta";}
            }
            aux = aux.getSiguiente();
        }
        return "No se encontro el usuario";
    }
    
    public String habilitarT(int cedula, String numeros) {
        NodoTarjeta aux = cabeza;
        while (aux != null) {
            if (aux.getTarjeta().getPropietario() == cedula && aux.getTarjeta().getNumeroTarjeta().equals(numeros)) { //lo busca si lo encuentra muestra los datos
                if(aux.getTarjeta().isActiva()){
                    return "Tarjeta ya activa";
                }else{
                aux.getTarjeta().setActiva(true);
                cabeza = aux;
                return "Se habilito la tarjeta";}
            }
            aux = aux.getSiguiente();
        }
        return "No se encontro el usuario";
    }

    @Override
    public String toString() {
        return "ListaTarjetas{" + "cabeza=" + cabeza + '}';
    }
    
    
}

