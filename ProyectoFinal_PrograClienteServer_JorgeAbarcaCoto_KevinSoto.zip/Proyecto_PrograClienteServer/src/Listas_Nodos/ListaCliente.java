/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Listas_Nodos;

import Clientes.Cliente;

/**
 *
 * @author XPC
 */
public class ListaCliente {
    private NodoCliente cabeza;

    public NodoCliente getCabeza() {
        return cabeza;
    }

    // Agrega personas en lista enlanzada
    public void inserta(Cliente dato){
        NodoCliente nuevo = new NodoCliente(dato);
        if(cabeza==null){
            cabeza = nuevo;
        }else if(dato.getId()<=cabeza.getCliente().getId()){
            nuevo.setSiguiente(cabeza);
            cabeza=nuevo;
        }else if(cabeza.getSiguiente()==null){
            cabeza.setSiguiente(nuevo);
        }else{
            NodoCliente aux=this.cabeza;
            while(aux.getSiguiente()!=null && aux.getSiguiente().getCliente().getId()<dato.getId()){
                aux=aux.getSiguiente();
            }
            nuevo.setSiguiente(aux.getSiguiente());
            aux.setSiguiente(nuevo);
        }
    }
    
    public String buscarT(int buscar, ListaTarjetas buscarT) {
    NodoCliente aux = cabeza;
    StringBuilder guardarT = new StringBuilder();
    boolean bandera=false;// para saber si lo encontramos
        while(aux!=null){
            if(aux.getCliente().getId()==buscar){ //lo busca si lo encuentra muestra los datos
                String guardar = "ID: " + aux.getCliente().getId() +
                        "\nNombre: " + aux.getCliente().getNombre() +
                        "\nApellido: "+aux.getCliente().getApellidos() +
                        "\nEmail: "+ aux.getCliente().getEmail()+
                        "\nNumero de Telefono: "+aux.getCliente().getTelefono()+"\n";
                if(aux.getCliente().isTarjeta()){
                    guardarT = buscarT.buscar(buscar);
                }
                return guardar+"\n"+guardarT.toString();
            }
            aux=aux.getSiguiente();
        }
        return "No se encontro el usuario";
    }
    
    public boolean encontrar(int buscar) {
    NodoCliente aux = cabeza;
    boolean bandera=false;// para saber si lo encontramos
        while(aux!=null){
            if(aux.getCliente().getId()==buscar){ //lo busca si lo encuentra muestra los datos
                return true;
            }
            aux=aux.getSiguiente();
        }
        return false;
    }
    
    public String buscarP(int buscar, int pin) {
    NodoCliente aux = cabeza;
        while(aux!=null){
            if(aux.getCliente().getId()==buscar && aux.getCliente().getPin()==pin){ //lo busca si lo encuentra muestra los datos
                return "ID: " + aux.getCliente().getId() +
                        "\nNombre: " + aux.getCliente().getNombre() +
                        "\nApellido: "+aux.getCliente().getApellidos() +
                        "\nEmail: "+ aux.getCliente().getEmail()+
                        "\nNumero de Telefono: "+aux.getCliente().getTelefono();
            }
            aux=aux.getSiguiente();
        }
        return "No se encontro el usuario";
    }
    
    public String buscar(int buscar) {
    NodoCliente aux = cabeza;
    boolean bandera=false;// para saber si lo encontramos
        while(aux!=null){
            if(aux.getCliente().getId()==buscar){ //lo busca si lo encuentra muestra los datos
                return "ID: " + aux.getCliente().getId() +
                        "\nNombre: " + aux.getCliente().getNombre() +
                        "\nApellido: "+aux.getCliente().getApellidos() +
                        "\nEmail: "+ aux.getCliente().getEmail()+
                        "\nNumero de Telefono: "+aux.getCliente().getTelefono();
            }
            aux=aux.getSiguiente();
        }
        return "No se encontro el usuario";
    }
    
    public Cliente buscarC(int buscar) {
    NodoCliente aux = cabeza;
    boolean bandera=false;// para saber si lo encontramos
        while(aux!=null){
            if(aux.getCliente().getId()==buscar){ //lo busca si lo encuentra muestra los datos
                return aux.getCliente();
            }
            aux=aux.getSiguiente();
        }
        return null;
    }
    
    public boolean cambiarInfo(Cliente cliente) {
    NodoCliente aux = cabeza;
    int buscar = cliente.getId();
    boolean bandera=false;// para saber si lo encontramos
        while(aux!=null){
            if(aux.getCliente().getId()==buscar){ //lo busca si lo encuentra muestra los datos
                aux.getCliente().setNombre(cliente.getNombre());
                aux.getCliente().setApellidos(cliente.getApellidos());
                aux.getCliente().setEmail(cliente.getEmail());
                aux.getCliente().setTelefono(cliente.getTelefono());
                aux.getCliente().setContra(cliente.getContra());
                aux.getCliente().setPin(cliente.getPin());
                aux.getCliente().setTarjeta(cliente.isTarjeta());
                return true;
            }
            aux=aux.getSiguiente();
        }
        return false;
    }
    
    public String cambiarEstadoT(int buscar) {
    NodoCliente aux = cabeza;
        while(aux!=null){
            if(aux.getCliente().getId()==buscar){ //lo busca si lo encuentra muestra los datos
                aux.getCliente().setTarjeta(true);
            }
            aux=aux.getSiguiente();
        }
        return "No se encontro el usuario";
    }
    
    public String cambiarEstadoF(int buscar) {
    NodoCliente aux = cabeza;
        while(aux!=null){
            if(aux.getCliente().getId()==buscar){ //lo busca si lo encuentra muestra los datos
                aux.getCliente().setTarjeta(false);
            }
            aux=aux.getSiguiente();
        }
        return "No se encontro el usuario";
    }
    
    public String mostrarNombres(){
        NodoCliente aux = cabeza;
        String guardar = "";
        int nombre = 0;
        while (aux != null) {
            guardar += "Nombre "+nombre+": ";
            guardar += aux.getCliente().getNombre();
            guardar+="\n";
            aux = aux.getSiguiente();
            nombre++;
        }
        return guardar;
    }
    
    public String mostrarClientes() {
        NodoCliente aux = cabeza;
        String guardar = "";
        while (aux != null) {
            guardar += aux.getCliente().MostrarDatos();
            guardar += "\n";
            aux = aux.getSiguiente();
        }
        return guardar;
    }

    @Override
    public String toString() {
        return "ListaCliente{" + "cabeza=" + cabeza + '}';
    }
    
    
}
