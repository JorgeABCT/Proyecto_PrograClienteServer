/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clientes;
import java.util.Random;
import java.time.LocalDate;
/**
 *
 * @author XPC
 */
import java.time.LocalDate;
import java.util.Random;

import java.time.LocalDate;
import java.util.Random;

import java.time.LocalDate;
import java.util.Random;

public class Tarjeta {
    private int propietario;
    private String numeroTarjeta;
    private int CVV;
    private String fechaVencimiento;
    private int balance;
    private boolean activa;

    public Tarjeta(int propietario) {
        LocalDate fecha = LocalDate.now();
        Random rand = new Random();
        StringBuilder numeros = new StringBuilder("5518");

        for (int i = 0; i < 12; i++) {
            int digito = rand.nextInt(10);
            numeros.append(digito);
        }

        StringBuilder cvv = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            int digito = rand.nextInt(10);
            cvv.append(digito);
        }

        int anno = fecha.getYear();
        int mes = fecha.getMonthValue();
        anno += 5;

        this.propietario = propietario;
        this.numeroTarjeta = numeros.toString();
        this.CVV = Integer.parseInt(cvv.toString());
        this.fechaVencimiento = String.format("%d-%02d-01", anno, mes);
        this.balance = 0;
        this.activa = false;
    }

    public Tarjeta(int propietario, String numeroTarjeta, int CVV, String fechaVencimiento, int balance, boolean activa) {
        this.propietario = propietario;
        this.numeroTarjeta = numeroTarjeta;
        this.CVV = CVV;
        this.fechaVencimiento = fechaVencimiento;
        this.balance = balance;
        this.activa = activa;
    }

    public int getPropietario() {
        return propietario;
    }

    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    public int getCVV() {
        return CVV;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public int getBalance() {
        return balance;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    @Override
    public String toString() {
        return "Propietario: " + propietario + "\nNumero de Tarjeta: " + numeroTarjeta +
                "\nCVV: " + CVV + "\nFecha de Vencimiento: " + fechaVencimiento + "\nBalance: " + balance;
    }
}



