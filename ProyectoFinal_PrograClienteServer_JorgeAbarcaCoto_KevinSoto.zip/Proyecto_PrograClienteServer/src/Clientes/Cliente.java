/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clientes;

/**
 *
 * @author XPC
 */

public class Cliente implements Persona {
    private int id;
    private String nombre, apellidos, email, telefono, contra;
    private int pin;
    private boolean tarjeta;
    private Tarjeta tarjetaCliente;  // Nuevo campo para la tarjeta del cliente

    public Cliente(int id, String nombre, String apellidos, String email, String telefono, String contra, int pin, boolean tarjeta) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.telefono = telefono;
        this.contra = contra;
        this.pin = pin;
        this.tarjeta = tarjeta;
        this.tarjetaCliente = null;  // Inicialmente no hay tarjeta asignada
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    public Tarjeta getTarjetaCliente() {
        return tarjetaCliente;
    }

    public void setTarjetaCliente(Tarjeta tarjetaCliente) {
        this.tarjetaCliente = tarjetaCliente;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public boolean isTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(boolean tarjeta) {
        this.tarjeta = tarjeta;
    }

    @Override
    public String MostrarDatos() {
        String datos = "ID: " + id + "\nNombre: " + nombre + "\nApellidos: " + apellidos +
                "\nEmail: " + email + "\nTelefono: " + telefono + "\nContra: " + contra;
        if (tarjetaCliente != null) {
            datos += "\nTarjeta: " + tarjetaCliente.toString();
        }
        return datos;
    }

    @Override
    public String toString() {
        return "Cliente{" + "id=" + id + ", nombre=" + nombre + ", apellidos=" + apellidos + ", email=" + email + ", telefono=" + telefono + ", contra=" + contra + ", pin=" + pin + ", tarjeta=" + tarjeta + ", tarjetaCliente=" + tarjetaCliente + '}';
    }
    
    
}

