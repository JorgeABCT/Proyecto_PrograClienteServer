/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Menu;

import Clientes.Cliente;
import Listas_Nodos.NodoCliente;
import Listas_Nodos.ListaTarjetas;
import Listas_Nodos.ListaCliente;
import Menu.jMenuPrincipal;
import Menu.jInicio;
import Menu.jBalance;
import Menu.EditarInfo;
import Clientes.Persona;
import javax.swing.JOptionPane;

/**
 *
 * @author XPC
 */
import javax.swing.*;
import java.awt.*;
import Manejo.ManejoBD;
import Clientes.Tarjeta;

public class Menu {

    private ManejoBD mane = new ManejoBD();
    private ListaCliente lista = new ListaCliente();
    private ListaTarjetas listaT = new ListaTarjetas();

    private JTextField idText;
    private JPasswordField pinField;
    
    private JFrame frame;


    public void Importar() {
        mane.Importar(lista);
        mane.importarT(listaT);
    }

    public void MostrarDatos() {
        JOptionPane.showMessageDialog(null, lista.mostrarClientes());
        JOptionPane.showMessageDialog(null, listaT.mostrarTarjetas());
    }

    public void MenuCliente() {
        frame = new JFrame("Menú Cliente");
        frame.setSize(300, 525);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().setBackground(new Color(34, 41, 50));
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(new Color(34, 41, 50));
        placeComponents(panel);

        frame.add(panel, BorderLayout.CENTER);
        
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
    
    public void MenuCliente(ListaCliente lista, ListaTarjetas listaT) {
        frame = new JFrame("Menú Cliente");
        frame.setSize(300, 525);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().setBackground(new Color(34, 41, 50));
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(new Color(34, 41, 50));
        placeComponents(panel);

        frame.add(panel, BorderLayout.CENTER);
        
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        this.lista = lista;
        this.listaT = listaT;
    }

    public void MenuEmpleado() {
        int opcion = 0;
        while (opcion != 6) {
            String[] opciones = {"Editar Info", "Crear Tarjeta", "Desactivar tarjeta", "Aceptar tarjeta", "Mostrar Info del Cliente", "Buscar Cliente", "Salir"};
            opcion = JOptionPane.showOptionDialog(
                    null,
                    "Seleccione una opción",
                    "Menu Cliente",
                    0,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    opciones,
                    opciones[5]
            );
            switch (opcion) {
                case 0: {
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog("Escriba cual es la cedula"));
                    Cliente buscar = lista.buscarC(cedula);
                    if (buscar != null) {
                        EditarInfo info = new EditarInfo(buscar, lista);
                        info.setVisible(true);
                        try {
                            // Pausa la ejecución del hilo actual durante 2 segundos
                            Thread.sleep(7000); // El argumento es el tiempo en milisegundos
                        } catch (InterruptedException e) {
                            // Manejo de excepciones
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No se encontro el cliente");
                    }
                    break;
                }
                case 1: {
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog("Escriba cual es la cedula"));
                    if (lista.encontrar(cedula)) {
                        Tarjeta nueva = new Tarjeta(cedula);
                        nueva.setActiva(true);
                        JOptionPane.showMessageDialog(null, "Tarjeta creada: " + nueva.toString());
                        listaT.agregarTarjetaBD(nueva);
                        mane.crearTarjeta(nueva);
                        lista.cambiarEstadoT(cedula);
                    }
                    break;
                }
                case 2: {
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog("Escriba la cedula del cliente"));
                    String numeros = JOptionPane.showInputDialog("Escriba los numeros de la tarjeta");
                    JOptionPane.showMessageDialog(null, listaT.deshabilitarT(cedula, numeros));
                    mane.deshabilitarT(cedula, numeros);
                    if (listaT.cantidadT(cedula) == 1) {
                        lista.cambiarEstadoF(cedula);
                    }
                    break;
                }
                case 3: {
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog("Escriba la cedula del cliente"));
                    String numeros = JOptionPane.showInputDialog("Escriba los numeros de la tarjeta");
                    JOptionPane.showMessageDialog(null, listaT.habilitarT(cedula, numeros));
                    mane.habilitarT(cedula, numeros);
                    lista.cambiarEstadoT(cedula);
                    break;
                }
                case 4: {
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog("Escriba la cedula del cliente"));
                    JOptionPane.showMessageDialog(null, lista.buscar(cedula));
                    break;
                }
                case 5: {
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog("Escriba la cedula del cliente"));
                    JOptionPane.showMessageDialog(null, lista.buscar(cedula));
                    JOptionPane.showMessageDialog(null, listaT.buscar(cedula));
                    break;
                }
                case 6: {
                    break;
                }
            }
        }
    }
    
    public void MenuP(){
        jMenuPrincipal menuP = new jMenuPrincipal(lista, listaT);
        menuP.setVisible(true);
    }

    public void MenuPrincipal() {
        int opcion = 0;
        String[] opciones = {"Menu Empleado", "Menu Cliente"};
        opcion = JOptionPane.showOptionDialog(
                null,
                "Seleccione una opción",
                "Menu Cliente",
                0,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opciones,
                opciones[0]
        );

        if (opcion == 0) {
            jInicio iniciar = new jInicio(lista, listaT);
            iniciar.setVisible(true);
        } else if(opcion ==1) {
            this.MenuCliente();
        }else{
            System.exit(0);
        }
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel idLabel = createLabel("ID:");
        positionComponent(idLabel, 20, 20, 80, 25);
        panel.add(idLabel);

        idText = createTextField();
        positionComponent(idText, 100, 20, 150, 25);
        panel.add(idText);
        idText.setText("");

        JLabel pinLabel = createLabel("PIN:");
        positionComponent(pinLabel, 20, 60, 80, 25);
        panel.add(pinLabel);

        pinField = createPasswordField();
        positionComponent(pinField, 100, 60, 150, 25);
        panel.add(pinField);
        pinField.setText("");

        JButton mostrarInfoButton = createButton("Mostrar Info");
        positionButton(mostrarInfoButton, 20, 100, 230, 30);
        panel.add(mostrarInfoButton);

        JButton solicitarTarjetaButton = createButton("Solicitar Tarjeta");
        positionButton(solicitarTarjetaButton, 20, 140, 230, 30);
        panel.add(solicitarTarjetaButton);

        JButton ingresarDineroButton = createButton("Ingresar Dinero");
        positionButton(ingresarDineroButton, 20, 180, 230, 30);
        panel.add(ingresarDineroButton);

        JButton retirarDineroButton = createButton("Retirar Dinero");
        positionButton(retirarDineroButton, 20, 220, 230, 30);
        panel.add(retirarDineroButton);

        JButton crearCuentaButton = createButton("Crear Cuenta");
        positionButton(crearCuentaButton, 20, 260, 230, 30);
        panel.add(crearCuentaButton);

        JButton salirButton = createButton("Salir");
        positionButton(salirButton, 20, 300, 230, 30);
        panel.add(salirButton);

        JPanel pinPadPanel = createPinPad();
        positionComponent(pinPadPanel, 20, 340, 230, 120);
        panel.add(pinPadPanel);

        // Action Listeners
        mostrarInfoButton.addActionListener(e -> {
            try {
                String buscar = idText.getText();
                char[] contrasenaChars = pinField.getPassword();
                String contrasena = new String(contrasenaChars);
                JOptionPane.showMessageDialog(null, lista.buscarP(Integer.parseInt(buscar), Integer.parseInt(contrasena)));
            } catch (Exception err) {
                JOptionPane.showMessageDialog(null, "Hubo un error al leer las variables\nPuede que el boton requiera de su pin para entrar\n"+err.getMessage());
            }
        });

        solicitarTarjetaButton.addActionListener(e -> {
            try {
                String idCliente = idText.getText();
                Cliente cliente = buscarClientePorID(idCliente);
                char[] contrasenaChars = pinField.getPassword();
                String contrasena = new String(contrasenaChars);
                if (cliente != null && cliente.getPin()==Integer.parseInt(contrasena)) {
                    Tarjeta nuevaTarjeta = solicitarTarjeta(cliente.getId());
                    cliente.setTarjetaCliente(nuevaTarjeta);
                    mane.crearTarjeta(nuevaTarjeta);
                    JOptionPane.showMessageDialog(null, "Tarjeta solicitada exitosamente:\n" + nuevaTarjeta.toString());
                } else if (cliente == null) {
                    JOptionPane.showMessageDialog(null, "Cliente no encontrado");
                } else {
                    JOptionPane.showMessageDialog(null, "Ya posee una tarjeta");
                }
            } catch (Exception err) {
                JOptionPane.showMessageDialog(null, "Hubo un error al leer las variables");
            }
        });

        ingresarDineroButton.addActionListener(e -> {
            try {
                String idCliente = idText.getText();
                char[] contrasenaChars = pinField.getPassword();
                String contrasena = new String(contrasenaChars);
                Cliente cliente = lista.buscarC(Integer.parseInt(idCliente));
                if (cliente != null && cliente.isTarjeta()) {
                    int tarjetas = listaT.cantidadT(Integer.parseInt(idCliente));
                    if (tarjetas == 0) {
                        JOptionPane.showMessageDialog(null, "Hubo un error al contactar la base de datos. \nPorfavor, hable con uno de nuestros funcionarios");
                    } else if (tarjetas == 1) {
                        Tarjeta numeros = listaT.getTarjeta(Integer.parseInt(idCliente));
                        jBalance balance = new jBalance(numeros, listaT, false);
                        balance.setVisible(true);
                    } else {
                        String[] opciones = listaT.getTarjetas(Integer.parseInt(idCliente), tarjetas);
                        Object seleccion = JOptionPane.showInputDialog(
                                null,
                                "Seleccione una tarjeta para ingresar dinero",
                                "Escoger una tarjeta",
                                JOptionPane.PLAIN_MESSAGE,
                                null,
                                opciones,
                                opciones[0]
                        );
                        int opcion = -1;  // Valor por defecto
                        for (int i = 0; i < opciones.length; i++) {
                            if (opciones[i].equals(seleccion)) {
                                opcion = i;
                                break;
                            }
                        }
                        Tarjeta numeros = listaT.getTarjeta(opciones[opcion]);
                        jBalance balance = new jBalance(numeros, listaT, false);
                        balance.setVisible(true);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "El usuario no tiene ninguna tarjeta");
                }
            } catch (Exception err) {
                JOptionPane.showMessageDialog(null, "Hubo un error al leer las variables\nPuede que el boton requiera de su pin para entrar");
            }
        });

        retirarDineroButton.addActionListener(e -> {
            try {
                String idCliente = idText.getText();
                char[] contrasenaChars = pinField.getPassword();
                String contrasena = new String(contrasenaChars);
                Cliente cliente = lista.buscarC(Integer.parseInt(idCliente));
                if (cliente != null && cliente.isTarjeta()) {
                    int tarjetas = listaT.cantidadT(Integer.parseInt(idCliente));
                    if (tarjetas == 0) {
                        JOptionPane.showMessageDialog(null, "Hubo un error al contactar la base de datos. \nPorfavor, hable con uno de nuestros funcionarios");
                    } else if (tarjetas == 1) {
                        Tarjeta numeros = listaT.getTarjeta(Integer.parseInt(idCliente));
                        jBalance balance = new jBalance(numeros, listaT, true);
                        balance.setVisible(true);
                    } else {
                        String[] opciones = listaT.getTarjetas(Integer.parseInt(idCliente), tarjetas);
                        Object seleccion = JOptionPane.showInputDialog(
                                null,
                                "Seleccione una tarjeta para ingresar dinero",
                                "Escoger una tarjeta",
                                JOptionPane.PLAIN_MESSAGE,
                                null,
                                opciones,
                                opciones[0]
                        );
                        int opcion = -1;  // Valor por defecto
                        for (int i = 0; i < opciones.length; i++) {
                            if (opciones[i].equals(seleccion)) {
                                opcion = i;
                                break;
                            }
                        }
                        Tarjeta numeros = listaT.getTarjeta(opciones[opcion]);
                        jBalance balance = new jBalance(numeros, listaT, true);
                        balance.setVisible(true);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "El usuario no tiene ninguna tarjeta");
                }
            } catch (Exception err) {
                JOptionPane.showMessageDialog(null, "Hubo un error al leer las variables\nPuede que el boton requiera de su pin para entrar");
            }
        });

        crearCuentaButton.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(null, "Quiere crear una cuenta?", "Confirmar",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                showCrearCuentaDialog();
            } else {
                JOptionPane.showMessageDialog(null, "Se ha cancelado la creación de cuenta");
            }
        });

        salirButton.addActionListener(e -> {
            char[] contrasenaChars = pinField.getPassword();
            String contrasena = new String(contrasenaChars);
            if (contrasena.equals("442266")) {
                frame.dispose();
            }
        });
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        return label;
    }

    private JLabel createLabelBL(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.BLACK);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        return label;
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField();
        textField.setBackground(new Color(200, 200, 200));
        textField.setForeground(Color.BLACK);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        return textField;
    }

    private JPasswordField createPasswordField() {
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBackground(new Color(200, 200, 200));
        passwordField.setForeground(Color.BLACK);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setEchoChar('\u25CF'); // Utiliza un círculo para ocultar los caracteres
        return passwordField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        customizeButton(button);
        return button;
    }

    private void customizeButton(JButton button) {
        button.setBackground(new Color(52, 152, 219));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        button.setFont(new Font("Arial", Font.PLAIN, 14));
    }

    private void positionComponent(Component component, int x, int y, int width, int height) {
        component.setBounds(x, y, width, height);
    }

    private void positionButton(JButton button, int x, int y, int width, int height) {
        positionComponent(button, x, y, width, height);
        button.addActionListener(e -> button.setBackground(new Color(44, 112, 157)));
    }

    private JPanel createPinPad() {
        JPanel pinPadPanel = new JPanel();
        pinPadPanel.setLayout(new GridLayout(4, 3));

        for (int i = 1; i <= 9; i++) {
            JButton button = createButton(Integer.toString(i));
            pinPadPanel.add(button);
            button.addActionListener(e -> pinField.setText(pinField.getText() + button.getText()));
        }

        JButton zeroButton = createButton("0");
        pinPadPanel.add(zeroButton);
        zeroButton.addActionListener(e -> pinField.setText(pinField.getText() + zeroButton.getText()));

        JButton clearButton = createButton("C");
        pinPadPanel.add(clearButton);
        clearButton.addActionListener(e -> pinField.setText(""));

        return pinPadPanel;
    }

    private void showCrearCuentaDialog() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));

        panel.add(createLabelBL("Nombre:"));
        JTextField nombreField = createTextField();
        panel.add(nombreField);

        panel.add(createLabelBL("Apellido:"));
        JTextField apellidoField = createTextField();
        panel.add(apellidoField);

        panel.add(createLabelBL("ID:"));
        JTextField idField = createTextField();
        panel.add(idField);

        panel.add(createLabelBL("Email:"));
        JTextField emailField = createTextField();
        panel.add(emailField);

        panel.add(createLabelBL("Teléfono:"));
        JTextField telefonoField = createTextField();
        panel.add(telefonoField);

        panel.add(createLabelBL("Contraseña:"));
        JPasswordField contrasenaField = createPasswordField();
        panel.add(contrasenaField);

        panel.add(createLabelBL("PIN:"));
        JTextField pinField = createTextField();
        panel.add(pinField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Cuenta", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText());
                int pin = Integer.parseInt(pinField.getText());

                JOptionPane.showMessageDialog(null, mane.insertarCliente(id,
                        nombreField.getText(), apellidoField.getText(),
                        emailField.getText(), telefonoField.getText(),
                        new String(contrasenaField.getPassword()), pin));

                lista.inserta(new Cliente(id, nombreField.getText(), apellidoField.getText(),
                        emailField.getText(), telefonoField.getText(),
                        new String(contrasenaField.getPassword()), pin, false));

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido para ID y PIN");
            }
        }
    }

    private String showInputDialog(String message) {
        return JOptionPane.showInputDialog(null, message);
    }

    private Cliente buscarClientePorID(String id) {
        NodoCliente aux = lista.getCabeza();
        while (aux != null) {
            if (String.valueOf(aux.getCliente().getId()).equals(id)) {
                return aux.getCliente();
            }
            aux = aux.getSiguiente();
        }
        return null;
    }

    private Tarjeta solicitarTarjeta(int propietario) {
        Tarjeta nuevaTarjeta = new Tarjeta(propietario);
        listaT.agregarTarjetaBD(nuevaTarjeta);
        return nuevaTarjeta;
    }
}
