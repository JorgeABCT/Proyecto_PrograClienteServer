/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Manejo;
import Clientes.Tarjeta;
import Listas_Nodos.ListaTarjetas;
import Listas_Nodos.ListaCliente;
import Clientes.Cliente;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author XPC
 */
public class ManejoBD {
    public static final String url = "jdbc:mysql://localhost:3306/proyecto_clienteserver";
    public static final String user = "root";
    public static final String pass = "";

    public static Connection getConnection(){
        Connection con = null;
        try{
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("Conexion exitosa!");
        } catch(Exception e){
            System.out.println("Hubo un error\n" + e.getMessage());
        }
        return con;
    }
    
    public void Importar(ListaCliente lista){
        try{
            String instruccion = "SELECT * FROM `cliente`";
            Connection con = ManejoBD.getConnection();
            PreparedStatement ps = con.prepareStatement(instruccion);
            ResultSet res = ps.executeQuery();
            while(res.next()){
                int id = Integer.parseInt(res.getString("id"));
                String nombre = res.getString("nombre");
                String apellidos = res.getString("apellidos");
                String email = res.getString("email");
                String telefono = res.getString("telefono");
                String contra = res.getString("contra");
                int pin = Integer.parseInt(res.getString("pin"));
                boolean tarjeta = false;
                if(res.getString("tarjeta").equals("1")){
                    tarjeta = true;
                }
                lista.inserta(new Cliente(id, nombre, apellidos, email, telefono, contra, pin, tarjeta));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Hubo un error al contactar la base de datos");
        }
    }
    
    public void importarT(ListaTarjetas lista){
        try{
            String instruccion = "SELECT * FROM `tarjetas`";
            Connection con = ManejoBD.getConnection();
            PreparedStatement ps = con.prepareStatement(instruccion);
            ResultSet res = ps.executeQuery();
            while(res.next()){
                int propietario = Integer.parseInt(res.getString("propietario"));
                String numerosT = res.getString("numeroT");
                int cvv = res.getInt("cvv");
                String fecha = res.getString("fechaV");
                int balance = res.getInt("balance");
                boolean tarjeta = false;
                if(res.getString("activa").equals("1")){
                    tarjeta = true;
                }
                lista.agregarTarjetaBD(new Tarjeta(propietario, numerosT, cvv, fecha, balance, tarjeta));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Hubo un error al contactar la base de datos\n"+e.getMessage());
        }
    }
    
    public String insertarCliente(int id, String nombre, String apellidos, String email, String telefono, String contra, int pin) {
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            
            StringBuilder instruccionC = new StringBuilder();
            instruccionC.append("Insert Into cliente(id,nombre,apellidos,email,telefono,contra,PIN,tarjeta) values (");
            instruccionC.append("'").append(id).append("',");
            instruccionC.append("'").append(nombre).append("',");
            instruccionC.append("'").append(apellidos).append("',");
            instruccionC.append("'").append(email).append("',");
            instruccionC.append("'").append(telefono).append("',");
            instruccionC.append("'").append(contra).append("',");
            instruccionC.append(pin).append(",");
            instruccionC.append(0);
            instruccionC.append(")");
            st.executeUpdate(instruccionC.toString());
            
            con.close();
            return "Se agrego el cliente de manera correcta!";
        } catch (SQLException ex) {
            return "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage();
        }
    }
    
    public void select(String id, String contra){
        Connection con = null;
        try{
            con = ManejoBD.getConnection();
            String instruccion = "SELECT * FROM `cliente` WHERE `id` = "+id+" AND `contra` = '"+contra+"'";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ResultSet res = ps.executeQuery();
            String boolT = "";
            if(res.next()){
            if(res.getString("tarjeta").equals("1")){
                boolT = "Tiene tarjetas";
            }else{
                boolT = "No tiene tarjetas";
            }
            JOptionPane.showMessageDialog(null, "Cedula: "+res.getString("id")+
                                                            "\nNombre: "+res.getString("nombre")+
                                                            "\nApellidos: "+res.getString("apellidos")+
                                                            "\nEmail: "+res.getString("email")+
                                                            "\nNumero celular: "+res.getString("telefono")+
                                                            "\n"+boolT);}
        } catch(Exception e){
            System.out.println("Hubo un error\n" + e.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close(); // Cierra la conexión aquí
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión\n" + e.getMessage());
            }
        }
    }
    //INSERT INTO `tarjetas` (`propietario`, `numeroT`, `cvv`, `fechaV`, `balance`, `activa`) VALUES ('119410503', '1111', '123', '2025-12-07', '0', '1');
    public void crearTarjeta(Tarjeta card){
        int active = 0;
        if(card.isActiva()){
            active++;
        }
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            
            StringBuilder instruccionC = new StringBuilder();
            instruccionC.append("INSERT INTO `tarjetas` (`propietario`, `numeroT`, `cvv`, `fechaV`, `balance`, `activa`) VALUES (");
            instruccionC.append("'").append(card.getPropietario()).append("',");
            instruccionC.append("'").append(card.getNumeroTarjeta()).append("',");
            instruccionC.append("'").append(card.getCVV()).append("',");
            instruccionC.append("'").append(card.getFechaVencimiento()).append("',");
            instruccionC.append("'").append(card.getBalance()).append("',");
            instruccionC.append("'").append(active).append("'");
            instruccionC.append(")");
            st.executeUpdate(instruccionC.toString());
            
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage());
        }
    }
    //UPDATE `tarjetas` SET `activa` = 1,  WHERE `propietario` = 119410503 AND `numeroT` = 5518370031120968
    public String deshabilitarT(int cedula, String numeros){
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            String instruccion = "UPDATE `tarjetas` SET `activa` = 0 WHERE `propietario` = ? AND `numeroT` = ?";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setString(1, Integer.toString(cedula));
            ps.setString(2, numeros);
            ps.execute();
            con.close();
            return "Tarjeta deshabilitada exitosamente";
        } catch (SQLException ex) {
            return "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage();
        }
    }
    //UPDATE `tarjetas` SET `balance` = 0 WHERE `numeroT`= 5518976366672956
    public String cambiarSaldo(int saldo, String numeros){
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            String instruccion = "UPDATE `tarjetas` SET `balance` = ? WHERE `numeroT`= ?";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setInt(1, saldo);
            ps.setString(2, numeros);
            ps.execute();
            con.close();
            return "Dinero ingresado exitosamente";
        } catch (SQLException ex) {
            return "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage();
        }
    }
    
    //SELECT * FROM `empleados` WHERE `usuario` = "" AND `contrasena` = ""
    
    public boolean iniciarEmpleado(String correo, String contra){
        try{
            String instruccion = "SELECT * FROM `empleados` WHERE `usuario` = ? AND `contrasena` = ?";
            Connection con = ManejoBD.getConnection();
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setString(1, correo);
            ps.setString(2, contra);
            ResultSet res = ps.executeQuery();
            if(res.next()){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Hubo un error al contactar la base de datos\n"+e.getMessage());
            return false;
        }
    }
    public String habilitarT(int cedula, String numeros){
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            String instruccion = "UPDATE `tarjetas` SET `activa` = 1 WHERE `propietario` = ? AND `numeroT` = ?";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setString(1, Integer.toString(cedula));
            ps.setString(2, numeros);
            ps.execute();
            con.close();
            return  "Tarjeta habilitada exitosamente";
        } catch (SQLException ex) {
            return "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage();
        }
    }
    
    //UPDATE `cliente` SET `id`='?',`nombre`='?',`apellidos`='?',`email`='?',`telefono`='?',`contra`='?',`PIN`='?',`tarjeta`='?' WHERE `id` = ?
    
    public String cambiarInfoC(Cliente cliente){
        try {
            int guardarT = 0;
            if(cliente.isTarjeta()){
                guardarT = 1;
            }
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            String instruccion = "UPDATE `cliente` SET `nombre`=?,`apellidos`=?,`email`=?,`telefono`=?,`contra`=?,`PIN`=?,`tarjeta`=? WHERE `id` = ?";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getApellidos());
            ps.setString(3, cliente.getEmail());
            ps.setString(4, cliente.getTelefono());
            ps.setString(5, cliente.getContra());
            ps.setInt(6, cliente.getPin());
            ps.setInt(7, guardarT);
            ps.setInt(8, cliente.getId());
            ps.execute();
            con.close();
            return  "Cambios realizados exitosamente";
        } catch (SQLException ex) {
            return "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage();
        }
    }
    
    //UPDATE `cliente` SET `tarjeta` = 1 WHERE `id` = 119410503
    public void cambiarEstadoT(int cedula){
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            String instruccion = "UPDATE `cliente` SET `tarjeta` = 1 WHERE `id` = ?";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setString(1, Integer.toString(cedula));
            ps.execute();
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage());
        }
    }
    
    public void cambiarEstadoF(int cedula){
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            String instruccion = "UPDATE `cliente` SET `tarjeta` = 0 WHERE `id` = ?";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setString(1, Integer.toString(cedula));
            ps.execute();
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage());
        }
    }
    
    public void eliminarTarjeta(int cedula, String numeros){
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            String instruccion = "DELETE FROM `tarjetas` WHERE `numeroT` = ? and `propietario` = ?";
            PreparedStatement ps = con.prepareStatement(instruccion);
            ps.setString(1, Integer.toString(cedula));
            ps.setString(2, numeros);
            ps.execute();
            con.close();
            JOptionPane.showMessageDialog(null, "Tarjeta eliminada exitosamente");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error con la comunicacion a la base de datos\n"+ex.getLocalizedMessage());
        }
    }
    
    public void eliminarCliente(String id){
        try {
            Connection con = ManejoBD.getConnection();
            Statement st = con.createStatement();
            
            String instruccion = "DELETE FROM `cliente` WHERE `cliente`.`id` = "+id;
            st.executeUpdate(instruccion);
            
            System.out.println("Datos eliminados correctamente");
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
